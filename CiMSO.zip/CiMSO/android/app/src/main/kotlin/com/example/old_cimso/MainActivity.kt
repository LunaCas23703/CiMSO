package com.example.old_cimso

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
