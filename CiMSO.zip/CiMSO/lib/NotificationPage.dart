import 'package:flutter/material.dart';

class NotificationsPage extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Notifications'),
      ),
      body: ListView(
        padding: EdgeInsets.all(16),
        children: [
          Text('General Notification', style: TextStyle(fontSize: 18)),
          Divider(),
          CheckboxListTile(
            title: Text('Sound'),
            value: true,
            onChanged: (bool? value) {},
          ),
          CheckboxListTile(
            title: Text('Vibrate'),
            value: true,
            onChanged: (bool? value) {},
          ),
          CheckboxListTile(
            title: Text('App Update'),
            value: true,
            onChanged: (bool? value) {},
          ),
          CheckboxListTile(
            title: Text('New Service Available'),
            value: true,
            onChanged: (bool? value) {},
          ),
          CheckboxListTile(
            title: Text('New tips enable'),
            value: true,
            onChanged: (bool? value) {},
          ),
        ],
      ),
    );
  }
}