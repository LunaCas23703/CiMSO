
import 'package:flutter/material.dart';
import 'package:old_cimso/TypeReservationPage.dart';
import 'package:old_cimso/intropage.dart';

import 'Account_setting.dart';
import 'EditPage.dart';
import 'PaymentPage.dart';
import 'SubscriptionPage.dart';

class ProfilePage extends StatelessWidget {
  const ProfilePage({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text("Profile")),
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            CircleAvatar(radius: 40),
            SizedBox(height: 10),
            Text("Michael Thar Stit", style: TextStyle(fontSize: 22)),
            Text("michaelthar.st@gmail.com"),
            SizedBox(height: 20),
            ElevatedButton(
              onPressed: () {
                Navigator.push(
                    context, MaterialPageRoute(builder: (context) => PaymentPage()));
              },
              child: Text("Go to Payment"),
            ),
            ElevatedButton(
              onPressed: () {
                Navigator.push(
                    context, MaterialPageRoute(builder: (context) => TypeReservationPage()));
              },
              child: Text("Type of Reservation"),
            ),
            ElevatedButton(
              onPressed: () {
                Navigator.push(
                    context, MaterialPageRoute(builder: (context) => SubscriptionPage()));
              },
              child: Text("Go to Subscription"),
            ),
            ElevatedButton(
              onPressed: () {
                Navigator.push(
                    context, MaterialPageRoute(builder: (context) => EditPage()));
              },
              child: Text("Edit Profile"),
            ),
            ElevatedButton(
              onPressed: () {
                Navigator.push(
                    context, MaterialPageRoute(builder: (context) => SecurityPage()));
              },
              child: Text("Security Settings"),
            ),
            ElevatedButton(
              onPressed: () {
                Navigator.push(
                    context, MaterialPageRoute(builder: (context) => HotelIntroPage()));
              },
              child: Text("Logout"),
            ),

          ],
        ),
      ),
    );
  }
}