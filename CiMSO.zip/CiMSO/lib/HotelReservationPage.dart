import 'package:flutter/material.dart';
import 'HotelDetailPage.dart';
import 'HotelReservationPageHistory.dart';
import 'ProfilePage.dart';
import 'SearchPage.dart';
import 'SelectDatePage.dart';
import 'TransactionPage.dart';
import 'TypeReservationPage.dart';

class HotelReservationPage extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text("Hotels"), centerTitle: true),
      body: ListView(
        padding: EdgeInsets.all(16),
        children: [
          HotelCard(
            name: "Castella Hotel",
            location: "3 more locations found",
            price: "฿ 1399/night",
            imageUrl: "assets/images/Room2.jpg",
            onTap: () {
              Navigator.push(
                context,
                MaterialPageRoute(builder: (context) => HotelDetailPage()),
              );
            },
          ),
          SizedBox(height: 10),
          HotelCard(
            name: "Grand Royal Hotel",
            location: "2 more locations found",
            price: "฿ 1599/night",
            imageUrl: "assets/images/Room3.jpg",
            onTap: () {
              Navigator.push(
                context,
                MaterialPageRoute(builder: (context) => HotelDetailPage()),
              );
            },
          ),
        ],
      ),
      bottomNavigationBar: CustomBottomNavBar(currentIndex: 0),
    );
  }
}

class HotelCard extends StatelessWidget {
  final String name;
  final String location;
  final String price;
  final String imageUrl;
  final VoidCallback onTap;

  HotelCard({required this.name, required this.location, required this.price, required this.imageUrl, required this.onTap});

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      child: Card(
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Image.asset(imageUrl, height: 150, width: double.infinity, fit: BoxFit.cover),
            Padding(
              padding: EdgeInsets.all(8.0),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(name, style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
                  SizedBox(height: 4),
                  Text(location, style: TextStyle(color: Colors.grey)),
                  SizedBox(height: 4),
                  Text(price, style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold)),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}


class BookingCompletionPage extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text("Booking Completed")),
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(Icons.check_circle, color: Colors.green, size: 100),
            SizedBox(height: 20),
            Text("Your booking has been successfully completed!", style: TextStyle(fontSize: 20)),
            SizedBox(height: 20),

            ElevatedButton(
              onPressed: () {
                Navigator.push(
                    context, MaterialPageRoute(builder: (context) => TransactionPage()));
              },
              child: Text("Transaction Page"),
            ),

            ElevatedButton(
              onPressed: () {
                Navigator.popUntil(context, (route) => route.isFirst);
              },
              child: Text("Back to Home"),
            ),
          ],
        ),
      ),
    );
  }
}

class CustomBottomNavBar extends StatelessWidget {
  final int currentIndex;

  const CustomBottomNavBar({Key? key, required this.currentIndex}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return BottomNavigationBar(
      currentIndex: currentIndex,
      selectedItemColor: Colors.brown,
      unselectedItemColor: Colors.grey,
      onTap: (index) {
        if (index == currentIndex) return;

        Widget page;
        switch (index) {
          case 0:
            page = TypeReservationPage();
            break;
          case 1:
            page = SearchPage();
            break;
          case 2:
            page = HotelReservationPageHistory();
            break;
          case 3:
            page = ProfilePage();
            break;
          default:
            return;
        }

        Navigator.pushReplacement(
          context,
          MaterialPageRoute(builder: (context) => page),
        );
      },
      items: [
        BottomNavigationBarItem(icon: Icon(Icons.home), label: "Home"),
        BottomNavigationBarItem(icon: Icon(Icons.search), label: "Search"),
        BottomNavigationBarItem(icon: Icon(Icons.book), label: "Booking"),
        BottomNavigationBarItem(icon: Icon(Icons.person), label: "Profile"),
      ],
    );
  }
}
