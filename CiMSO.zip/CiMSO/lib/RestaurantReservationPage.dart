import 'package:flutter/material.dart';
import 'HotelDetailPage.dart';
import 'HotelReservationPageHistory.dart';
import 'ProfilePage.dart';
import 'SearchPage.dart';
import 'TransactionPage.dart';
import 'TypeReservationPage.dart';

void main() {
  runApp(MaterialApp(
    home: RestaurantReservationPage(),
  ));
}

class RestaurantReservationPage extends StatefulWidget {
  @override
  _RestaurantReservationPageState createState() =>
      _RestaurantReservationPageState();
}

class _RestaurantReservationPageState extends State<RestaurantReservationPage> {
  DateTime? selectedDate;
  String selectedTime = "18:00 - 19:00";
  int guests = 2;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text("Restaurant Reservation")),
      body: Padding(
        padding: EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text("Pick your date",
                style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
            SizedBox(height: 10),
            Row(
              children: List.generate(5, (index) {
                return Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 4.0),
                  child: ChoiceChip(
                    label: Text("${21 + index} Apr"),
                    selected: selectedDate == DateTime(2025, 4, 21 + index),
                    onSelected: (selected) {
                      setState(() {
                        selectedDate = DateTime(2025, 4, 21 + index);
                      });
                    },
                  ),
                );
              }),
            ),
            SizedBox(height: 20),
            Text("Pick your time",
                style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
            DropdownButton<String>(
              value: selectedTime,
              items: ["18:00 - 19:00", "19:00 - 20:00", "20:00 - 21:00"]
                  .map((time) => DropdownMenuItem(value: time, child: Text(time)))
                  .toList(),
              onChanged: (value) {
                setState(() {
                  selectedTime = value!;
                });
              },
            ),
            SizedBox(height: 20),
            Text("How many people?",
                style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
            Row(
              children: [
                IconButton(
                  icon: Icon(Icons.remove),
                  onPressed: () {
                    setState(() {
                      if (guests > 1) guests--;
                    });
                  },
                ),
                Text("$guests"),
                IconButton(
                  icon: Icon(Icons.add),
                  onPressed: () {
                    setState(() {
                      guests++;
                    });
                  },
                ),
              ],
            ),
            SizedBox(height: 20),
            ElevatedButton(
              onPressed: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(
                      builder: (context) => ConfirmReservationPage(
                          date: selectedDate,
                          time: selectedTime,
                          guests: guests)),
                );
              },
              child: Text("Reserve"),
            ),
          ],
        ),
      ),
      bottomNavigationBar: CustomBottomNavBar(currentIndex: 2),
    );
  }
}

class ConfirmReservationPage extends StatelessWidget {
  final DateTime? date;
  final String time;
  final int guests;

  ConfirmReservationPage({this.date, required this.time, required this.guests});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text("Confirm Reservation")),
      body: Padding(
        padding: EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text("Your Reservation",
                style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold)),
            SizedBox(height: 10),
            Text("Date: ${date?.day} April 2025"),
            Text("Time: $time"),
            Text("Guests: $guests"),
            SizedBox(height: 20),
            ElevatedButton(
              onPressed: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(builder: (context) => OrderFoodPage()),
                );
              },
              child: Text("Confirm"),
            ),
          ],
        ),
      ),
    );
  }
}

class OrderFoodPage extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text("Order Food")),
      body: ListView(
        children: [
          ListTile(title: Text("Breakfast Buffets - ฿299"), trailing: Icon(Icons.add_shopping_cart)),
          ListTile(title: Text("Dinner Buffet - ฿499"), trailing: Icon(Icons.add_shopping_cart)),
          ListTile(title: Text("Set Menu 1 - ฿399"), trailing: Icon(Icons.add_shopping_cart)),
          ListTile(title: Text("Set Menu 2 - ฿299"), trailing: Icon(Icons.add_shopping_cart)),

    SizedBox(height: 16),
    Center(
    child: ElevatedButton(
    onPressed: () {
    Navigator.push(
    context,
    MaterialPageRoute(builder: (context) => BookingCompletionPage()),
    );
    },
    style: ElevatedButton.styleFrom(
    backgroundColor: Colors.brown,
    padding: EdgeInsets.symmetric(horizontal: 24, vertical: 12),
    shape: RoundedRectangleBorder(
    borderRadius: BorderRadius.circular(8),
    ),
    ),
    child: Text("Book Now", style: TextStyle(fontSize: 16)),
    ),
    ),
        ],
    ),
      bottomNavigationBar: CustomBottomNavBar(currentIndex: 2),
    );
  }
}

class ReservationCompletionPage extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text("Booking Completed")),
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(Icons.check_circle, color: Colors.green, size: 100),
            SizedBox(height: 20),
            Text("Your booking has been successfully completed!",
                style: TextStyle(fontSize: 20)),
            SizedBox(height: 20),
            ElevatedButton(
              onPressed: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(builder: (context) => TransactionPage()),
                );
              },
              child: Text("Transaction"),
            ),
            ElevatedButton(
              onPressed: () {
                Navigator.popUntil(context, (route) => route.isFirst);
              },
              child: Text("Back to Home"),
            ),
          ],
        ),
      ),
    );
  }
}

class CustomBottomNavBar extends StatelessWidget {
  final int currentIndex;
  CustomBottomNavBar({required this.currentIndex});

  @override
  Widget build(BuildContext context) {
    return BottomNavigationBar(
      currentIndex: currentIndex,
      selectedItemColor: Colors.brown,
      unselectedItemColor: Colors.grey,
      onTap: (index) {
        switch (index) {
          case 0:
            Navigator.push(context, MaterialPageRoute(builder: (context) => TypeReservationPage()));
            break;
          case 1:
            Navigator.push(context, MaterialPageRoute(builder: (context) => SearchPage()));
            break;
          case 2:
            Navigator.push(context, MaterialPageRoute(builder: (context) => RestaurantReservationPage()));
            break;
          case 3:
            Navigator.push(context, MaterialPageRoute(builder: (context) => ProfilePage()));
            break;
        }
      },
      items: [
        BottomNavigationBarItem(icon: Icon(Icons.home), label: "Home"),
        BottomNavigationBarItem(icon: Icon(Icons.search), label: "Search"),
        BottomNavigationBarItem(icon: Icon(Icons.book), label: "Booking"),
        BottomNavigationBarItem(icon: Icon(Icons.person), label: "Profile"),
      ],
    );
  }
}
