
import 'package:flutter/material.dart';

import 'NotificationPage.dart';
import 'PaymentPage.dart';
import 'ProfilePage.dart';

class EditPage extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: CustomScrollView(
        slivers: [
          // SliverAppBar for a scrollable app bar
          SliverAppBar(
            title: Text('Edit Profile'),
            floating: true, // App bar appears when scrolling up
            snap: true,     // App bar snaps into view when scrolling up
            expandedHeight: 100, // Height when expanded
            flexibleSpace: FlexibleSpaceBar(
              background: Container(
                color: Colors.blue, // Customize the background color
              ),
            ),
          ),
          // SliverList for the rest of the content
          SliverList(
            delegate: SliverChildListDelegate([
              Padding(
                padding: const EdgeInsets.all(16.0),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.stretch,
                  children: [
                    TextField(
                      decoration: InputDecoration(labelText: 'Full Name'),
                    ),
                    SizedBox(height: 16),
                    TextField(
                      decoration: InputDecoration(labelText: 'Nick Name'),
                    ),
                    SizedBox(height: 16),
                    TextField(
                      decoration: InputDecoration(labelText: 'Date of Birth'),
                    ),
                    SizedBox(height: 16),
                    TextField(
                      decoration: InputDecoration(labelText: 'Email'),
                    ),
                    SizedBox(height: 16),
                    TextField(
                      decoration: InputDecoration(labelText: 'Phone Number'),
                    ),
                    SizedBox(height: 16),
                    TextField(
                      decoration: InputDecoration(labelText: 'Gender'),
                    ),
                    SizedBox(height: 24),
                    ElevatedButton(
                      onPressed: () {
                        // Navigate to only one screen at a time
                        Navigator.push(
                          context,
                          MaterialPageRoute(builder: (context) => ProfilePage()),
                        );
                        ElevatedButton(
                          onPressed: () {
                            Navigator.push(
                              context,
                              MaterialPageRoute(builder: (context) => PaymentPage()),
                            );
                          },
                          child: Text('Go to Payment Page'),
                        );
                        ElevatedButton(
                        onPressed: () {
                        Navigator.push(
                        context,
                        MaterialPageRoute(builder: (context) => NotificationsPage()),
                        );
                        },
                        child: Text('Go to Notifications Page'),
                        );
                      },
                      child: Text('Update'),
                    ),
                  ],
                ),
              ),
            ]),
          ),
        ],
      ),
    );
  }
}