
import 'package:flutter/material.dart';
import 'HotelReservationPageHistory.dart';
import 'ProfilePage.dart';
import 'TypeReservationPage.dart';

class SearchPage extends StatelessWidget {
  final List<Map<String, dynamic>> hotels = [
    {
      "name": "Castella Hotel",
      "location": "Bangkok, Thailand",
      "price": "฿3599",
      "rating": 4.8,
      "reviews": "6,283 reviews",
      "image": "assets/hotel1.jpg"
    },
    {
      "name": "Castella Royal Hotel",
      "location": "Phuket, Thailand",
      "price": "฿4599",
      "rating": 4.8,
      "reviews": "6,283 reviews",
      "image": "assets/hotel2.jpg"
    },
    {
      "name": "Castella Delight Hotel",
      "location": "ChiangMai, Thailand",
      "price": "฿4099",
      "rating": 4.8,
      "reviews": "6,283 reviews",
      "image": "assets/hotel3.jpg"
    },
    {
      "name": "Castella Hotel",
      "location": "Hua Hin, Thailand",
      "price": "฿3599",
      "rating": 4.8,
      "reviews": "6,283 reviews",
      "image": "assets/hotel4.jpg"
    },
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: Colors.white,
        elevation: 0,
        title: TextField(
          decoration: InputDecoration(
            hintText: "Search",
            prefixIcon: Icon(Icons.search, color: Colors.grey),
            filled: true,
            fillColor: Colors.grey[200],
            border: OutlineInputBorder(
              borderRadius: BorderRadius.circular(30),
              borderSide: BorderSide.none,
            ),
          ),
        ),
      ),
      body: Padding(
        padding: EdgeInsets.symmetric(horizontal: 16.0, vertical: 8.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // Filter Buttons
            SingleChildScrollView(
              scrollDirection: Axis.horizontal,
              child: Row(
                children: [
                  filterButton("All Hotel", isSelected: true),
                  filterButton("Recommended"),
                  filterButton("Trending"),
                  filterButton("Top Rated"),
                ],
              ),
            ),
            SizedBox(height: 16),

            // Recommended Hotels Title
            Text(
              "Recommended (586,379)",
              style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
            ),
            SizedBox(height: 10),

            // Hotels List
            Expanded(
              child: ListView.builder(
                itemCount: hotels.length,
                itemBuilder: (context, index) {
                  final hotel = hotels[index];
                  return hotelCard(hotel);
                },
              ),
            ),
          ],
        ),
      ),

      // Bottom Navigation Bar
      bottomNavigationBar: BottomNavigationBar(
        selectedItemColor: Colors.orange,
        unselectedItemColor: Colors.grey,
        showSelectedLabels: true,
        showUnselectedLabels: true,
        items: [
          BottomNavigationBarItem(icon: Icon(Icons.home), label: "Home"),
          BottomNavigationBarItem(icon: Icon(Icons.search), label: "Search"),
          BottomNavigationBarItem(icon: Icon(Icons.book), label: "Booking"),
          BottomNavigationBarItem(icon: Icon(Icons.person), label: "Profile"),
        ],
      ),
    );
  }

  // Function to create filter buttons
  Widget filterButton(String text, {bool isSelected = false}) {
    return Padding(
      padding: EdgeInsets.only(right: 8),
      child: Chip(
        label: Text(text),
        backgroundColor: isSelected ? Colors.orange : Colors.grey[200],
        labelStyle: TextStyle(color: isSelected ? Colors.white : Colors.black),
      ),
    );
  }

  // Function to create hotel cards
  Widget hotelCard(Map<String, dynamic> hotel) {
    return Card(
      margin: EdgeInsets.symmetric(vertical: 8),
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
      child: ListTile(
        leading: ClipRRect(
          borderRadius: BorderRadius.circular(8),
          child: Image.asset(
            hotel["image"],
            width: 80,
            height: 80,
            fit: BoxFit.cover,
          ),
        ),
        title: Text(
          hotel["name"],
          style: TextStyle(fontWeight: FontWeight.bold),
        ),
        subtitle: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(hotel["location"], style: TextStyle(color: Colors.grey)),
            Row(
              children: [
                Icon(Icons.star, color: Colors.orange, size: 16),
                SizedBox(width: 4),
                Text("${hotel["rating"]} (${hotel["reviews"]})"),
              ],
            ),
          ],
        ),
        trailing: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Text(hotel["price"], style: TextStyle(fontWeight: FontWeight.bold)),
            Icon(Icons.bookmark_border, color: Colors.grey),
          ],
        ),
      ),
    );
  }
}
class CustomBottomNavBar extends StatelessWidget {
  final int currentIndex;

  const CustomBottomNavBar({Key? key, required this.currentIndex}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return BottomNavigationBar(
      currentIndex: currentIndex,
      selectedItemColor: Colors.brown,
      unselectedItemColor: Colors.grey,
      onTap: (index) {
        if (index == currentIndex) return; // Prevent reloading the same page

        Widget page;
        switch (index) {
          case 0:
            page = TypeReservationPage();
            break;
          case 1:
            page = SearchPage();
            break;
          case 2:
            page = HotelReservationPageHistory();
            break;
          case 3:
            page = ProfilePage();
            break;
          default:
            return;
        }

        Navigator.pushReplacement(
          context,
          MaterialPageRoute(builder: (context) => page),
        );
      },
      items: [
        BottomNavigationBarItem(icon: Icon(Icons.home), label: "Home"),
        BottomNavigationBarItem(icon: Icon(Icons.search), label: "Search"),
        BottomNavigationBarItem(icon: Icon(Icons.book), label: "Booking"),
        BottomNavigationBarItem(icon: Icon(Icons.person), label: "Profile"),
      ],
    );
  }
}

