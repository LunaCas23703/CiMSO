
import 'package:flutter/material.dart';

import 'ProfilePage.dart';

class SubscriptionPage extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text("Subscription")),
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Text("Subscription Levels", style: TextStyle(fontSize: 20)),
            ListTile(
              leading: Icon(Icons.star),
              title: Text("Bronze Membership"),
              subtitle: Text("Basic benefits"),
              trailing: ElevatedButton(
                onPressed: () {},
                child: Text("Upgrade"),
              ),
            ),
            ListTile(
              leading: Icon(Icons.star_half),
              title: Text("Silver Membership"),
              subtitle: Text("More perks"),
              trailing: ElevatedButton(
                onPressed: () {},
                child: Text("Upgrade"),
              ),
            ),
            ListTile(
              leading: Icon(Icons.star_border),
              title: Text("Platinum Membership"),
              subtitle: Text("Exclusive privileges"),
              trailing: ElevatedButton(
                onPressed: () {},
                child: Text("Upgrade"),
              ),
            ),
              ElevatedButton(
              onPressed: () {
    Navigator.push(
    context, MaterialPageRoute(builder: (context) => ProfilePage()));
    },
        child: Text("Back to Profile"),
            ),
          ],
        ),
      ),
    );
  }
}
