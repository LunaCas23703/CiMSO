import 'package:flutter/material.dart';
import 'ProfilePage.dart';

class HotelReservationPageHistory extends StatefulWidget {
  @override
  _HotelReservationPageHistoryState createState() => _HotelReservationPageHistoryState();
}

class _HotelReservationPageHistoryState extends State<HotelReservationPageHistory> {
  int _selectedTabIndex = 0;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text("Booking History"),
        leading: IconButton(
          icon: Icon(Icons.arrow_back),
          onPressed: () => Navigator.pop(context),
        ),
      ),
      body: Column(
        children: [
          // Tabs for filtering bookings
          Padding(
            padding: const EdgeInsets.symmetric(vertical: 10.0),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceEvenly,
              children: [
                _buildTabButton("Current", 0),
                _buildTabButton("Completed", 1),
                _buildTabButton("Canceled", 2),
              ],
            ),
          ),

          // Content Section
          Expanded(
            child: _getTabContent(),
          ),
        ],
      ),

      // Navigation to Profile Page
      floatingActionButton: FloatingActionButton(
        onPressed: () {
          Navigator.push(
            context,
            MaterialPageRoute(builder: (context) => ProfilePage()),
          );
        },
        child: Icon(Icons.person),
        tooltip: "Go to Profile",
      ),
    );
  }

  // Widget for Tab Button
  Widget _buildTabButton(String title, int index) {
    return ElevatedButton(
      style: ElevatedButton.styleFrom(
        backgroundColor: _selectedTabIndex == index ? Colors.brown : Colors.grey[300],
      ),
      onPressed: () {
        setState(() {
          _selectedTabIndex = index;
        });
      },
      child: Text(
        title,
        style: TextStyle(color: _selectedTabIndex == index ? Colors.white : Colors.black),
      ),
    );
  }

  // Returns the appropriate content based on selected tab
  Widget _getTabContent() {
    switch (_selectedTabIndex) {
      case 0:
        return _buildBookingCard("Current", "Castella Hotel", "Bangkok, Thailand", "4th March 2025", "10:00 AM");
      case 1:
        return _buildBookingCard("Completed", "Castella Hotel", "Bangkok, Thailand", "20th Feb 2025", "2:00 PM");
      case 2:
        return _buildCanceledBooking();
      default:
        return Container();
    }
  }

  // Booking Card for Current & Completed Bookings
  Widget _buildBookingCard(String status, String hotelName, String location, String date, String time) {
    return Card(
      margin: EdgeInsets.all(12),
      elevation: 3,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
      child: Padding(
        padding: EdgeInsets.all(12),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text("Pick up", style: TextStyle(color: Colors.red, fontWeight: FontWeight.bold)),
            SizedBox(height: 5),
            Row(
              children: [
                Icon(Icons.place, color: Colors.red),
                SizedBox(width: 5),
                Text(location),
              ],
            ),
            Row(
              children: [
                Icon(Icons.calendar_today, color: Colors.brown),
                SizedBox(width: 5),
                Text(date),
              ],
            ),
            Row(
              children: [
                Icon(Icons.access_time, color: Colors.blue),
                SizedBox(width: 5),
                Text(time),
              ],
            ),
            SizedBox(height: 10),
            Text("Hotel: $hotelName", style: TextStyle(fontWeight: FontWeight.bold)),
            Text(location),
            SizedBox(height: 10),
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                ElevatedButton(
                  onPressed: () {},
                  child: Text("Export"),
                ),
                ElevatedButton(
                  onPressed: () {},
                  style: ElevatedButton.styleFrom(backgroundColor: Color(0xFFA86B32)),
                  child: Text("Cancel", style: TextStyle(color: Colors.black)),

                ),
              ],
            ),
          ],
        ),
      ),
    );
  }

  // Special UI for Canceled Bookings
  Widget _buildCanceledBooking() {
    return Column(
      children: [
        _buildBookingCard("Canceled", "Castella Hotel", "Bangkok, Thailand", "4th March 2025", "10:00 AM"),
        SizedBox(height: 10),
        Card(
          margin: EdgeInsets.all(12),
          color: Colors.brown[200],
          child: Padding(
            padding: EdgeInsets.all(12),
            child: Column(
              children: [
                Text("Do you want to try another option?", style: TextStyle(fontWeight: FontWeight.bold)),
                ListTile(
                  leading: Icon(Icons.hotel),
                  title: Text("Castella Hotel"),
                  subtitle: Text("Bangkok, Thailand"),
                  trailing: Text("฿3599"),
                ),
                ListTile(
                  leading: Icon(Icons.hotel),
                  title: Text("Castella Royal Hotel"),
                  subtitle: Text("Phuket, Thailand"),
                  trailing: Text("฿4599"),
                ),
              ],
            ),
          ),
        ),
      ],
    );
  }
}
