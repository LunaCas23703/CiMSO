import 'package:flutter/material.dart';

class RewardsPage extends StatefulWidget {
  @override
  _RewardsPage createState() => _RewardsPage();
}

class _RewardsPage extends State<RewardsPage> {
  int selectedIndex = 1; // Default to "Redeem"

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text("Member Card"),
        leading: IconButton(
          icon: Icon(Icons.arrow_back),
          onPressed: () => Navigator.pop(context),
        ),
      ),
      body: Column(
        children: [
          Padding(
            padding: const EdgeInsets.all(16.0),
            child: Container(
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(12),
                gradient: LinearGradient(
                  colors: [Colors.orange.shade700, Colors.orange.shade400],
                ),
              ),
              padding: EdgeInsets.all(16),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text("Royal Card", style: TextStyle(color: Colors.white, fontSize: 18)),
                  SizedBox(height: 5),
                  Text("Current Point", style: TextStyle(color: Colors.white70)),
                  Text("2500", style: TextStyle(color: Colors.white, fontSize: 24, fontWeight: FontWeight.bold)),
                  SizedBox(height: 5),
                  Text("1 point = 2.5 baht", style: TextStyle(color: Colors.white70)),
                ],
              ),
            ),
          ),
          TabBarSection(selectedIndex: selectedIndex, onTabChanged: (index) {
            setState(() {
              selectedIndex = index;
            });
          }),
          Expanded(
            child: ListView(
              padding: EdgeInsets.all(16),
              children: [
                RewardCategory(title: "Hotel Room", rewards: [
                  RewardItem(title: "Deluxe 50% off", points: 4500),
                  RewardItem(title: "King Premium 50% off", points: 9990),
                  RewardItem(title: "Classic 50% off", points: 8240),
                ]),
                RewardCategory(title: "Restaurant", rewards: [
                  RewardItem(title: "Set Menu 50% off", points: 440),
                  RewardItem(title: "Buffets 50% off", points: 740),
                ]),
              ],
            ),
          ),
        ],
      ),
      bottomNavigationBar: BottomNavigationBar(
        type: BottomNavigationBarType.fixed,
        backgroundColor: Colors.orange.shade700,
        selectedItemColor: Colors.white,
        unselectedItemColor: Colors.white70,
        items: [
          BottomNavigationBarItem(icon: Icon(Icons.home), label: "Home"),
          BottomNavigationBarItem(icon: Icon(Icons.shopping_bag), label: "Offer"),
          BottomNavigationBarItem(icon: Icon(Icons.card_giftcard), label: "Reward"),
          BottomNavigationBarItem(icon: Icon(Icons.person), label: "Profile"),
        ],
      ),
    );
  }
}

class TabBarSection extends StatelessWidget {
  final int selectedIndex;
  final Function(int) onTabChanged;

  TabBarSection({required this.selectedIndex, required this.onTabChanged});

  @override
  Widget build(BuildContext context) {
    return Row(
      mainAxisAlignment: MainAxisAlignment.center,
      children: ["Earn", "Redeem", "History"].asMap().entries.map((entry) {
        int idx = entry.key;
        String text = entry.value;
        return GestureDetector(
          onTap: () => onTabChanged(idx),
          child: Padding(
            padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 8),
            child: Text(
              text,
              style: TextStyle(
                fontSize: 16,
                fontWeight: FontWeight.bold,
                color: selectedIndex == idx ? Colors.orange.shade700 : Colors.grey,
              ),
            ),
          ),
        );
      }).toList(),
    );
  }
}

class RewardCategory extends StatelessWidget {
  final String title;
  final List<RewardItem> rewards;

  RewardCategory({required this.title, required this.rewards});

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Padding(
          padding: const EdgeInsets.symmetric(vertical: 8.0),
          child: Text(title, style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
        ),
        Column(children: rewards),
      ],
    );
  }
}

class RewardItem extends StatelessWidget {
  final String title;
  final int points;

  RewardItem({required this.title, required this.points});

  @override
  Widget build(BuildContext context) {
    return Card(
      margin: EdgeInsets.symmetric(vertical: 5),
      child: ListTile(
        title: Text(title, style: TextStyle(fontSize: 16)),
        trailing: Row(
          mainAxisSize: MainAxisSize.min,
          children: [
            Icon(Icons.monetization_on, color: Colors.orange),
            SizedBox(width: 5),
            Text(points.toString()),
          ],
        ),
      ),
    );
  }
}