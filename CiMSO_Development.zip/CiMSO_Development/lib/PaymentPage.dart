

import 'package:flutter/material.dart';

class PaymentPage extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Payment Methods'),
      ),
      body: ListView(
        padding: EdgeInsets.all(16),
        children: [
          ListTile(
            title: Text('Add new card'),
            onTap: () {
              // Add new card functionality
            },
          ),
          Divider(),
          ListTile(
            title: Text('Apple Pay'),
          ),
          ListTile(
            title: Text('Shop Volummed'),
            subtitle: Text('1004 5499  1005 5388'),
          ),
          ListTile(
            title: Text('New Card'),
            subtitle: Text('1004 (x= 000%)'),
          ),
          Divider(),
          ListTile(
            title: Text('Continue'),
            onTap: () {
              // Continue to payment
            },
          ),
        ],
      ),
    );
  }
}