
import 'package:flutter/material.dart';
import 'ProfilePage.dart';
import 'SignupPage.dart';


class LoginPage extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Login to your Account'),
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            TextField(
              decoration: InputDecoration(labelText: 'Email'),
            ),
            SizedBox(height: 16),
            TextField(
              decoration: InputDecoration(labelText: 'Password'),
              obscureText: true,
            ),
            CheckboxListTile(
              title: Text('Remember me'),
              value: false,
              onChanged: (bool? value) {},
            ),
            ElevatedButton(
              onPressed: () {
                Navigator.push(
                    context,
                    MaterialPageRoute(builder: (context) =>ProfilePage()));
              },
              child: Text('Sign in', style: TextStyle(color: Colors.black)),
              style: ElevatedButton.styleFrom(backgroundColor: Color(0xFFA86B32)),
            ),
            TextButton(
              onPressed: () {},
              child: Text('Forgot password?'),
            ),
            Center(child: Text('or continue with')),
            // Add social login buttons here
            TextButton(
              onPressed: () {
                Navigator.push(
                    context,
                    MaterialPageRoute(builder: (context) =>SignUpPage()));
              },
              child: Text("Don't have an account? Sign up"),
            ),
          ],
        ),
      ),
    );
  }
}
