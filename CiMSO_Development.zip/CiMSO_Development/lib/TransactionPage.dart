import 'package:flutter/material.dart';


class TransactionPage extends StatelessWidget {

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('History'),
        actions: [
          IconButton(
            icon: const Icon(Icons.logout),
            onPressed: () {},
          ),
        ],
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          children: [
            _buildDropdown('Today'),
            _buildTransactionItem(3999.00, '3d4456Vb12a', 'Receiver', '23/2/2025'),
            _buildTransactionItem(1599.00),
            _buildTransactionItem(1399.00),
            _buildTransactionItem(1599.00),
            _buildDropdown('Last 1 Week Ago'),
            const Spacer(),
            ElevatedButton(
              style: ElevatedButton.styleFrom(
                backgroundColor: Colors.brown,
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(20),
                ),
              ),
              onPressed: () {},
              child: const Padding(
                padding: EdgeInsets.symmetric(horizontal: 20, vertical: 10),
                child: Text(
                  'Delete Transaction & Cache',
                  style: TextStyle(color: Colors.black, fontWeight: FontWeight.bold),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildDropdown(String title) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 10),
      decoration: BoxDecoration(
        color: Colors.brown[800],
        borderRadius: BorderRadius.circular(5),
      ),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Text(title, style: const TextStyle(fontSize: 16, color: Colors.white)),
          const Icon(Icons.arrow_drop_down, color: Colors.white),
        ],
      ),
    );
  }

  Widget _buildTransactionItem(double amount, [String? code, String? receiver, String? date]) {
    return Card(
      color: Colors.brown[500],
      child: ListTile(
        title: Text('Objective', style: const TextStyle(color: Colors.white)),
        subtitle: code != null
            ? Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text('Transaction Code: $code', style: const TextStyle(color: Colors.grey)),
            Text('Transfer to: $receiver', style: const TextStyle(color: Colors.grey)),
            Text('Transaction Date: $date', style: const TextStyle(color: Colors.grey)),
          ],
        )
            : null,
        trailing: Text('$amount B', style: const TextStyle(color: Colors.brown, fontWeight: FontWeight.bold)),
      ),
    );
  }
}