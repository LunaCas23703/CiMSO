import 'package:flutter/material.dart';
import 'ProfilePage.dart';
import 'RewardsPage.dart';
import 'TypeReservationPage.dart';

class SubscriptionPage extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text("Membership Levels")),
      body: SingleChildScrollView(
        child: Padding(
          padding: const EdgeInsets.all(16.0),
          child: Column(
            children: [
              Center(
                child: MembershipCard(
                  level: "Bronze",
                  points: "3,000",
                  benefits: [
                    "Free Festival gifts",
                    "10% Off Discounts",
                    "Exclusive Icon",
                    "Gift Cards",
                  ],
                  color: Colors.brown.shade300,
                ),
              ),
              Center(
                child: MembershipCard(
                  level: "Silver",
                  points: "6,000",
                  benefits: [
                    "Free Festival gifts",
                    "20% Off Discounts",
                    "Exclusive Icon",
                    "VIP Lounges",
                    "Complimentary breakfast",
                  ],
                  color: Colors.grey,
                ),
              ),
              Center(
                child: MembershipCard(
                  level: "Platinum",
                  points: "10,000",
                  benefits: [
                    "Free Festival gifts",
                    "40% Off Discounts",
                    "Exclusive Icon",
                    "VIP Lounges",
                    "Complimentary breakfast",
                    "Free Upgrade",
                    "Free Night",
                  ],
                  color: Colors.blueGrey,
                ),
              ),
            ],
          ),
        ),
      ),
      bottomNavigationBar: BottomNavigationBar(
        onTap: (index) {
          switch (index) {
            case 0:
              Navigator.pushReplacement(
                  context, MaterialPageRoute(builder: (context) => TypeReservationPage()));
              break;
            case 1:
              Navigator.pushReplacement(
                  context, MaterialPageRoute(builder: (context) => RewardsPage()));
              break;
            case 2:
              Navigator.pushReplacement(
                  context, MaterialPageRoute(builder: (context) => ProfilePage()));
              break;
          }
        },
        items: [
          BottomNavigationBarItem(icon: Icon(Icons.home), label: "Home"),
          BottomNavigationBarItem(icon: Icon(Icons.card_giftcard), label: "Rewards"),
          BottomNavigationBarItem(icon: Icon(Icons.person), label: "Profile"),
        ],
      ),
    );
  }
}

class MembershipCard extends StatelessWidget {
  final String level;
  final String points;
  final List<String> benefits;
  final Color color;

  MembershipCard({
    required this.level,
    required this.points,
    required this.benefits,
    required this.color,
  });

  @override
  Widget build(BuildContext context) {
    return Card(
      color: color,
      margin: EdgeInsets.symmetric(vertical: 10, horizontal: 20),
      child: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.center,
          children: [
            Text(
              "$level Membership",
              style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold, color: Colors.white),
            ),
            SizedBox(height: 5),
            Text("Total Points: $points", style: TextStyle(color: Colors.white70)),
            SizedBox(height: 10),
            Column(
              crossAxisAlignment: CrossAxisAlignment.center,
              children: benefits.map((benefit) => Text("- $benefit", style: TextStyle(color: Colors.white))).toList(),
            ),
          ],
        ),
      ),
    );
  }
}