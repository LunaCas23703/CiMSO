import 'package:flutter/material.dart';

class SecurityPage extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Security'),
      ),
      body: ListView(
        padding: EdgeInsets.all(16),
        children: [
          CheckboxListTile(
            title: Text('Face ID'),
            value: true,
            onChanged: (bool? value) {},
          ),
          CheckboxListTile(
            title: Text('Remember me'),
            value: true,
            onChanged: (bool? value) {},
          ),
          CheckboxListTile(
            title: Text('Touch ID'),
            value: true,
            onChanged: (bool? value) {},
          ),
          Divider(),
          ListTile(
            title: Text('Change Password'),
            onTap: () {
              // Navigate to change password page
            },
          ),
        ],
      ),
    );
  }
}