import 'package:flutter/material.dart';
import 'HotelReservationPage.dart';
import 'RestaurantReservationPage.dart';
import 'SearchPage.dart';
import 'HotelReservationPageHistory.dart';
import 'ProfilePage.dart';

class TypeReservationPage extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Booking Type'),
        centerTitle: true,
        leading: IconButton(
          icon: Icon(Icons.arrow_back),
          onPressed: () {
            Navigator.pop(context);
          },
        ),
      ),
      body: Center(
        child: Padding(
          padding: const EdgeInsets.symmetric(horizontal: 16.0, vertical: 20.0),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              _buildReservationCard(
                context,
                icon: Icons.king_bed,
                label: 'Hotel',
                color: Colors.brown,
                destination: HotelReservationPage(),
              ),
              SizedBox(height: 20),
              _buildReservationCard(
                context,
                icon: Icons.restaurant,
                label: 'Restaurant',
                color: Colors.brown,
                destination: RestaurantReservationPage(),
              ),
            ],
          ),
        ),
      ),
      bottomNavigationBar: CustomBottomNavBar(currentIndex: 0),
    );
  }

  Widget _buildReservationCard(BuildContext context,
      {required IconData icon,
        required String label,
        required Color color,
        required Widget destination}) {
    return GestureDetector(
      onTap: () {
        Navigator.push(
          context,
          MaterialPageRoute(builder: (context) => destination),
        );
      },
      child: Container(
        width: double.infinity,
        padding: EdgeInsets.all(25),
        decoration: BoxDecoration(
          color: Colors.grey[200],
          borderRadius: BorderRadius.circular(15),
        ),
        child: Column(
          children: [
            Icon(icon, size: 100, color: color),
            SizedBox(height: 10),
            Text(label,
                style:
                TextStyle(fontSize: 20, fontWeight: FontWeight.bold, color: color)),
          ],
        ),
      ),
    );
  }
}

class CustomBottomNavBar extends StatelessWidget {
  final int currentIndex;

  const CustomBottomNavBar({Key? key, required this.currentIndex}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return BottomNavigationBar(
      currentIndex: currentIndex,
      selectedItemColor: Colors.brown,
      unselectedItemColor: Colors.grey,
      onTap: (index) {
        if (index == currentIndex) return; // Prevent reloading the same page

        Widget page;
        switch (index) {
          case 0:
            page = TypeReservationPage();
            break;
          case 1:
            page = SearchPage();
            break;
          case 2:
            page = HotelReservationPageHistory();
            break;
          case 3:
            page = ProfilePage();
            break;
          default:
            return;
        }

        Navigator.pushReplacement(
          context,
          MaterialPageRoute(builder: (context) => page),
        );
      },
      items: [
        BottomNavigationBarItem(icon: Icon(Icons.home), label: "Home"),
        BottomNavigationBarItem(icon: Icon(Icons.search), label: "Search"),
        BottomNavigationBarItem(icon: Icon(Icons.book), label: "Booking"),
        BottomNavigationBarItem(icon: Icon(Icons.person), label: "Profile"),
      ],
    );
  }
}
